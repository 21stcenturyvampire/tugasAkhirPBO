/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

/**
 *
 * @author rj
 */
import Database.Koneksi;
import Model.Siswa;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
public class SiswaDAO {
    public static long insertSiswa(Siswa siswa) throws SQLException {
        String sql = "INSERT INTO siswa" +
                "(nama, nisn, unit, kelas, alamat, nomor_telepon)" +
                "VALUES (?, ?, ?, ?, ?, ?)";
        
        Connection conn = Koneksi.getConnection();
        PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        
        ps.setString(1, siswa.nama);
        ps.setString(2, siswa.nisn);
        ps.setString(3, siswa.unit);
        ps.setString(4, siswa.kelas);
        ps.setString(5, siswa.alamat);
        ps.setString(6, siswa.nomorTelepon);
        
        ps.executeUpdate();
        
        ResultSet rs = ps.getGeneratedKeys();
        
        long idBaru = 0;
        
        if (rs.next()){
            idBaru = rs.getLong(1);
        }
        
        rs.close();
        ps.close();
        conn.close();
        
        return idBaru;
    }
    
    
    public static void updateNilaiRaport(long idSiswa, double nilaiRaport) throws SQLException {
        String sql = "UPDATE siswa SET nilai_raport = ? WHERE id_siswa = ?";
        
        Connection conn = Koneksi.getConnection();
        PreparedStatement ps = conn.prepareStatement(sql);
        
        ps.setDouble(1, nilaiRaport);
        ps.setLong(2, idSiswa);
        
        ps.executeUpdate();

        ps.close();
        conn.close();
    }
}
