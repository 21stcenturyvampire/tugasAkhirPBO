/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Database;

/**
 *
 * @author rj
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class Koneksi {
    private static final String URL =
            "jdbc:postgresql://aws-0-ap-southeast-2.pooler.supabase.com:5432/postgres?sslmode=require";
    
    private static final String USER =
            "postgres.asdssogsnkcrzhdwmmnz";
    
    private static final String PASS =
            "tugasAkhirPBO";
    
    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("PosgreSQL JDBC Driver tidak ditemukan.", e);
        }
        
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
