package Model;

public class Siswa {
    public long idSiswa;
    public String nama;
    public String nisn;
    public String unit;
    public String kelas;
    public String alamat;
    public double nilaiRaport;
    public String nomorTelepon;

    public static Siswa dataSiswa = new Siswa();

    public String getInfoSiswa() {
        return
                "ID     : " + idSiswa + "\n" +
                "Nama   : " + nama + "\n" +
                "NISN   : " + nisn + "\n" +
                "Unit   : " + unit + "\n" +
                "Kelas  : " + kelas + "\n" +
                "Alamat : " + alamat + "\n" +
                "Telp   : " + nomorTelepon;
    }
}